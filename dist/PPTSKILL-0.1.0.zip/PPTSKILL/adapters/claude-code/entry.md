# Claude Code → PPTSKILL thin entry

你是 Claude Code 的 PPTSKILL 薄入口；安裝程式會把正式 `pptskill` Skill 註冊到 user skills。使用者可用 `/pptskill` 明確啟動。唯一 shared core 位於 `../../core`，不要複製或另建 renderer。

所有相對路徑都必須從本 `adapter.json` 所在目錄解析，不得從使用者目前工作目錄解析。以下 `<pptskill-runtime>` 是已安裝 runtime 的絕對路徑。

1. 先以 `node <pptskill-runtime>/profile.mjs show` 讀取選配偏好；profile 不存在是正常狀態。
2. 讀 `<pptskill-runtime>/core/working-spec.md` 與 `<pptskill-runtime>/core/schemas/`，保留 DeckSpec／StyleSpec／CompositionSpec 分離。
3. 新簡報先以 `workflow-cli.mjs preflight-new --brief <brief.json>` 取得唯一 preflight report 與 Grill state，再使用 `<pptskill-runtime>/core/runtime/grill-outline.js` 完成單題 Grill Me 與人工 outline gate；Style 選定後，把 preflight `generationPermissions`、selected `styleSpec`、每頁一筆 allowlisted `semanticSignals` 與 `rhythmSignals` 帶入 `workflow-cli.mjs plan-new --request <plan-request.json>`，只採用 Deck Rhythm Plan 從 ranked `available` candidates 中選出的 proposal，且不得改寫 approved content。rhythm signal 只含 density／emphasis／evidenceWeight／motionIntensity／sectionRole／optional continuityGroup；保留 intentional repetition，不以 diversity 覆蓋 semantic score boundary。semantic signal 不得夾帶 prompt、私密 metadata 或 raw asset bytes；自報 `user-provided` 只有在 ID／type 符合 approved outline component inventory 時才可免 generation opt-in。`goldenRouting` 只提供 Golden design logic，不得改 rank／primitive；`none` 合法，禁止抓取或複製 Golden 圖片、模板、DOM、CSS 或第三方 asset。Optional motion 只可由同一 request 的 allowlisted `motionSignals` 觸發：B odometer 限 `available` metric-grid；E underline sweep 限 optional `content.title` 接 required `content.subtitle`，role 由 ref 派生。只套用 `available` proposal 回傳的 `compositionMotion`；unsupported text/number format 或 `motionIntensity: none` 保持靜態。既有 HTML 也不可跳過一次 pressure test 與人類確認。
3a. Optional background 只可由 allowlisted `backgroundSignals` 觸發，且只套用 `available` proposal 的 `compositionBackgroundEffect`；不得偷換 unavailable effect，也不得加入 shader／selector／URL／provider。
3b. `sampleCount` 只可為 0／1／2；1 張沿用回傳的 `both`，2 張沿用互異的 `typical`／`stress` 與 reason codes，不得自行改取前兩頁。0 只跳過人工 sample wait，`fullDeckQaRequired` 仍為 true，sample PASS 不替代 full-deck QA。
3c. 人工 sample approval 前必須以 `workflow-cli.mjs qa-sample --request <qa-request.json>` 跑唯一 hard gate；每個代表頁完整提供 allowlisted evidence。`not_run`／`unknown` 保持 blocked，同一 `slideId + issue code` 共用最多兩次 repair budget，只執行 gate 回傳的 bounded action，不覆寫 last-success artifact。
3d. 人工明確核准後，以 `workflow-cli.mjs approve-sample --request <approval-request.json>` 重播同一 hard-gate request 並建立 freeze。回饋只接受 `slide-local | deck-wide | profile-opt-in`；只修補並重驗 invalidated 樣張，deck-wide 只套未核准頁，preserved 樣張不得靜默重生，profile 只有 `remember: true` 才可另行寫入。
4. 不得直接呼叫 `renderFullDeck()` 或自行寫 final HTML；只能用 `<pptskill-runtime>/core/runtime/workflow-cli.mjs` 產生輸出。既有 HTML 預設保留內容、頁序與 slide ID，任何變更必須有逐項人工核准的 change set。export 必須遵守 `<pptskill-runtime>/core/contracts/export-sanitizer-allowlist.md`。
5. 依 shared core 的 browser geometry 與既有 acceptance 規則驗收，不在 adapter 內新增第二套流程。
