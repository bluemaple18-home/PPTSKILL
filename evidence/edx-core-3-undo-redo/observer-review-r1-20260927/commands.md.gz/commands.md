# R1 Reviewer fresh 重播

reviewedSHA 固定 8e6094582547205db70f6dccce369d694f50154b；原 review 的 probe.py 保持原樣。以下命令重建專屬 TMPDIR，結束清除本輪 fixture。三項预期 exit0；不必重跑已保存證據才可閱讀 receipt。

```sh
set -e
cd /private/tmp/ai-core-pptskill-observer-20260927
review_tmp=$(mktemp -d /private/tmp/observer-r1-replay-XXXXXX)
trap 'rm -rf -- "$review_tmp"' EXIT HUP INT TERM
export TMPDIR="$review_tmp" PYTHONDONTWRITEBYTECODE=1
/Users/matt/ai-core/.venv/bin/python -B -m unittest discover -s tests -p test_tmp_artifact_lifecycle.py -k BrowserObserverRecoveryTests -k scan -k runtime_budget -k runtime_unknown -k browser_symlink_exceptions -k browser_rejects_other -v
/Users/matt/ai-core/.venv/bin/python -B /private/tmp/observer-independent-20260927-MRrZ71/probe.py
/Users/matt/ai-core/.venv/bin/python -B /private/tmp/observer-independent-20260927-MRrZ71/r1/direct-probe.py
```

本輪實際 TMPDIR 為本 r1 目錄內 fixtures，已清除。依序 stdout/stderr 保存到 fresh-suite.raw.log、original-probe.raw.jsonl、direct-probe.raw.jsonl；各 exit code 保存到同名 .exit.txt。沒有排除 Python sleep unit，它不是 PGQ。
