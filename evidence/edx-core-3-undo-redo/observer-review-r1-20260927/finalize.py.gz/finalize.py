import hashlib, json, shutil, subprocess
from pathlib import Path
repo = Path('/private/tmp/ai-core-pptskill-observer-20260927')
out = Path('/private/tmp/observer-independent-20260927-MRrZ71/r1')
sha, base = '8e6094582547205db70f6dccce369d694f50154b', 'c3724ce6b9e2584b9a25a41bf617edf818011e26'
expected = {'scripts/tmp_artifact_lifecycle.py': '6a6dc198e34cd43a95003f66280b37800fca737aa241d76019a9f3a573ddcee0', 'tests/test_tmp_artifact_lifecycle.py': '0392399157c92f34be76e4a1b9656570a834c4c88a8c450ffa0a3bd7a9c95805', 'docs/tmp-session-lifecycle.md': '84e37796766b475775db2dd3ab93a3f868605c57c4da33bef055db362d683fc1'}
def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args])
identities = {}
for name, target in expected.items():
    disk = hashlib.sha256((repo / name).read_bytes()).hexdigest()
    blob = hashlib.sha256(git('show', sha + ':' + name)).hexdigest()
    assert disk == blob == target
    identities[name] = {'expected': target, 'workingTreeSHA256': disk, 'commitBlobSHA256': blob}
assert git('rev-parse', 'HEAD').decode().strip() == sha
assert git('rev-parse', sha + '^').decode().strip() == base
status = git('status', '--porcelain=v1').decode()
assert not status
(out / 'status-after.txt').write_text(status)
changed = git('diff', '--name-only', base, sha).decode().splitlines()
assert all(name in expected or name.startswith('.work/PPTSKILL-OBSERVER-REPAIR-20260927-R1/') for name in changed)
check = subprocess.run(['git', '-C', str(repo), 'diff', '--check', base, sha], capture_output=True)
(out / 'diff-check.raw.log').write_bytes(check.stdout + check.stderr)
assert check.returncode == 0
history = {}
for line in (out / 'history-before.sha256').read_text().splitlines():
    previous, path = line.split('  ', 1)
    current = hashlib.sha256(Path(path).read_bytes()).hexdigest()
    assert previous == current
    history[path] = current
for name in ('fresh-suite', 'original-probe', 'direct-probe'):
    assert (out / (name + '.exit.txt')).read_text().strip() == '0'
fixture = out / 'fixtures'
remaining = sorted(str(p.relative_to(fixture)) for p in fixture.rglob('*'))
assert remaining == ['xcrun_db'], remaining
shutil.rmtree(fixture)
verification = {'reviewedSHA': sha, 'base': base, 'sources': identities, 'changedPaths': changed,
 'worktreeClean': True, 'diffCheckExit': check.returncode, 'historyUnchanged': history,
 'fresh': {'boundedSuiteTests': 50, 'boundedSuitePassed': 50, 'seconds': 3.351,
           'originalProbes': 18, 'originalProbesPassed': 18, 'directRepairProbes': 5, 'directRepairProbesPassed': 5,
           'all23ProbeDescriptorChecksPassed': True, 'excludedTests': []},
 'findings': {'P1_observed_budget_loss': 'CLOSED', 'P2_first_fstat_nlink_loss': 'CLOSED', 'newFindingsInTargetedScope': []},
 'fixtureCleanup': {'ownedPath': str(fixture), 'remainingBeforeRemoval': remaining, 'existsAfter': fixture.exists()},
 'verdict': 'CODE GO', 'scope': 'Original P1/P2 and direct repair regressions only',
 'limits': ['HOST_BLOCKED', 'NOT_ACTIVATED', 'No Chrome/PGQ/host benchmark', 'No whole-card GO', 'Not an atomic filesystem snapshot']}
(out / 'verification.json').write_text(json.dumps(verification, indent=2) + '\n')
print(json.dumps({'reviewedSHA': sha, 'threeHashesMatch': True, 'historyUnchanged': True, 'worktreeClean': True, 'fixturesRemoved': not fixture.exists(), 'verdict': 'CODE GO'}))
