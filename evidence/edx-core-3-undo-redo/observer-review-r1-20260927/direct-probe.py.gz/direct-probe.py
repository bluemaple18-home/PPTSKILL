import importlib.util, json, os, stat, sys, tempfile
from collections import Counter
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch
repo = Path('/private/tmp/ai-core-pptskill-observer-20260927')
sys.path.insert(0, str(repo))
spec = importlib.util.spec_from_file_location('candidate_r1', repo / 'scripts/tmp_artifact_lifecycle.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
real_open, real_close, real_fstat, real_scan = os.open, os.close, os.fstat, os.scandir

def run(kind, initial_size, final_size, ceiling, expected):
    with tempfile.TemporaryDirectory(prefix='r1-direct-') as tmp:
        root = Path(tmp)
        (root / 'a').mkdir()
        (root / 'a' / 'prior').write_bytes(b'a' * 64)
        parent = root / 'z'
        parent.mkdir()
        (parent / 'a-prefix').write_bytes(b'b' * 8)
        target = parent / 'pending'
        target.write_bytes(b'c' * initial_size)
        target_inode = target.stat().st_ino
        if kind == 'stable_hardlink':
            os.link(target, parent / 'alias')
        file_limit = 4 if kind == 'stable_hardlink' else 3
        opened, closed, events = [], [], []
        samples, renamed = 0, False
        def track_open(*args, **kwargs):
            fd = real_open(*args, **kwargs)
            opened.append(fd)
            return fd
        def track_close(fd):
            closed.append(fd)
            return real_close(fd)
        def sample(fd):
            nonlocal samples
            info = real_fstat(fd)
            if stat.S_ISREG(info.st_mode) and info.st_ino == target_inode:
                samples += 1
                if kind != 'stable_hardlink' and samples == 3:
                    moved = parent / 'committed'
                    moved.write_bytes(b'd' * final_size)
                    info = real_fstat(fd)
                    moved.write_bytes(b'c' * initial_size)
                events.append({'fstat_sample': samples, 'size': info.st_size, 'nlink': info.st_nlink})
            return info
        class Entry:
            def __init__(self, entry):
                self.entry, self.name = entry, entry.name
            def inode(self):
                return self.entry.inode()
            def stat(self, *, follow_symlinks=True):
                nonlocal renamed
                if self.name == 'pending' and not renamed and kind != 'stable_hardlink':
                    target.rename(parent / 'committed')
                    renamed = True
                    events.append('real same-parent rename before entry.stat')
                return self.entry.stat(follow_symlinks=follow_symlinks)
        @contextmanager
        def scan(fd):
            with real_scan(fd) as entries:
                yield iter([Entry(entry) for entry in sorted(entries, key=lambda item: item.name)])
        with patch.dict(m.OWNED_ROOTS, {str(root): {'browser_layout': True}}), \
             patch.object(m.os, 'open', side_effect=track_open), \
             patch.object(m.os, 'close', side_effect=track_close), \
             patch.object(m.os, 'fstat', side_effect=sample), \
             patch.object(m.os, 'scandir', side_effect=scan):
            try:
                value = m.scan_resource_artifacts(root, {'max_bytes': ceiling, 'max_file_count': file_limit})
                actual = 'ACCEPT'
            except m.LifecycleError as error:
                actual, value = 'REJECT', str(error)
        exact = (72 + initial_size * (2 if kind == 'stable_hardlink' else 1), file_limit)
        valid = actual == expected
        if actual == 'ACCEPT':
            valid = valid and value == exact
        else:
            valid = valid and 'bytes=88/87; files=3/3' in value
        closed_ok = Counter(opened) == Counter(closed)
        print(json.dumps({'case': kind, 'initial': initial_size, 'remaining': final_size, 'max_bytes': ceiling,
                          'expected': expected, 'actual': actual, 'value': value, 'contract_met': valid,
                          'descriptors_closed': closed_ok, 'events': events}), flush=True)
        assert valid and closed_ok
        assert kind == 'stable_hardlink' or samples == 3

for case in [('remaining_over', 8, 16, 87, 'REJECT'),
             ('remaining_equal', 8, 16, 88, 'ACCEPT'),
             ('remaining_shrink', 8, 0, 80, 'ACCEPT'),
             ('zero_length_found', 0, 0, 72, 'ACCEPT'),
             ('stable_hardlink', 8, 8, 88, 'ACCEPT')]:
    run(*case)
print(json.dumps({'summary': {'cases': 5, 'contract_failures': [], 'all_descriptors_closed': True}}))
