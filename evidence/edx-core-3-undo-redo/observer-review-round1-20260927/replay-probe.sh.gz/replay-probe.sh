#!/bin/sh
set -u
probe_tmp=$(mktemp -d /private/tmp/observer-independent-replay-XXXXXX) || exit 2
trap 'rm -rf -- "$probe_tmp"' EXIT HUP INT TERM
TMPDIR="$probe_tmp" PYTHONDONTWRITEBYTECODE=1 /Users/matt/ai-core/.venv/bin/python -B /private/tmp/observer-independent-20260927-MRrZ71/probe.py
