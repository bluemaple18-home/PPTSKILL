import sys, unittest
from pathlib import Path
repo = Path('/private/tmp/ai-core-pptskill-observer-20260927')
sys.path.insert(0, str(repo))
loader = unittest.TestLoader()
loader.testNamePatterns = ['*' + name + '*' for name in ['BrowserObserverRecoveryTests', 'scan', 'runtime_budget', 'runtime_unknown', 'browser_symlink_exceptions', 'browser_rejects_other']]
suite = loader.discover(str(repo / 'tests'), pattern='test_tmp_artifact_lifecycle.py')
def flatten(group):
    for item in group:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item
selected = []
for test in flatten(suite):
    if 'slow_resource_scan_does_not_overlap_or_trigger_catch_up_storm' in test.id():
        print('EXCLUDED_PGQ:', test.id(), flush=True)
    else:
        selected.append(test)
print('SELECTED:', len(selected), flush=True)
result = unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(selected))
sys.exit(not result.wasSuccessful())
