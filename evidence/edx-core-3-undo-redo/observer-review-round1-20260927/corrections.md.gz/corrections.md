# 2026-09-27 更正附記：排除測試的理由

本附記依 Mainline 更正追加，與原 receipt.md 一併閱讀；原 receipt、verification.json、runner、raw logs 與 evidence-sha256.txt 均保留原樣，不回寫歷史證據。

原 receipt 宣稱 `test_slow_resource_scan_does_not_overlap_or_trigger_catch_up_storm` 會啟動 PGQ，因此因禁令排除，這個理由不正確。已唯讀核對 tests/test_tmp_artifact_lifecycle.py:770：實際 child command 是 `[sys.executable, "-c", "import time; time.sleep(0.6)"]`。測試透過 run_child 執行短暫 Python sleep 子程序，沒有啟動 PGQ；不可把呼叫 run_child 等同於啟動 PGQ。

精確結果仍為 fresh 46/46 PASS；該項確實未執行，屬 Reviewer 誤判後排除，並非使用者 PGQ 禁令所必需。此更正亦適用 verification.json 的 excluded 理由、runner/raw 的 EXCLUDED_PGQ 標籤及當時對話中的相同敘述；這些歷史檔案保持原樣，不把 46 項改稱 47 項。

原 receipt SHA256：228335d51a174f4c7e4656bc20d76be688a443183b63a3cb58c27afd9cf7ddb3；追加附記前已核對與原 evidence-sha256.txt 一致。

Mainline 回報其 fresh replay 同樣重現3個反例（18總項、15符合契約），並已將唯一 bounded repair 交原 Writer。此為 Mainline 回報，不冒稱 Reviewer 新執行的證據。原 reviewedSHA 的 CODE NO-GO 不因排除理由更正而改變；修復版尚未重審。

本輪僅追加此更正附記，未修改 candidate、未執行新 probes 或測試。等待 fixed commit 的明確 re-review handoff。
