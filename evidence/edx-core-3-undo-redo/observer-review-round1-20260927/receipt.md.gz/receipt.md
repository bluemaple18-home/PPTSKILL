# 獨立 CODE Review：NO-GO

reviewedSHA：`c3724ce6b9e2584b9a25a41bf617edf818011e26`。base：`c23e46555b73a29f16319c657622acb1acc51e7a`。commit parent、三個 Git blob SHA256、磁碟檔案與 Owner 凍結值全部一致；詳 verification.json。最後 worktree clean，完整 base→commit diff check exit 0。

此為獨立唯讀 CODE 審查。未改 candidate/main/產品或歷史 fixtures；未啟動 Chrome、PGQ、merge、push、deploy。自己的 runner、probe、raw、receipt 僅存本目錄。CodeGraph 先以 /Users/matt/ai-core 查 scanner/caller 邊界，再核對 candidate diff。以 correctness、regression、安全邊界與測試缺口自行裁決；未採 Writer verdict 作結論。

## Finding 1 — P1：已觀察的超額可被縮檔抹掉

位置：`scripts/tmp_artifact_lifecycle.py:1150`、`:1163`、`:1145`、`:1189`。

首次 `os.fstat(file_fd)` 僅投影 identity，丟掉 size；ENOENT 分支只比較 before 與第二次 pinned 大小。獨立 `observed_peak`：fresh stat=8 bytes → 真實擴檔至128 → 首次 fstat **確實讀到128** → 真實縮檔至8並同 parent rename → entry.stat 回真 ENOENT → pinned/replay=8。max_bytes=64，候選卻成功回 `(8,1)`。

另一接點 `replay_peak`：完成同 parent rename 後，重讀前真實擴檔至128；重讀的 fresh nofollow stat **確實讀到128**，隨後縮檔至8，entry.stat=8，仍成功回 `(8,1)`。1189 僅使用較晚 info.st_size，未拒絕先前已看見的超額。

這不是要求原子 filesystem snapshot，而是已有 syscall 回傳的超額證據被候選丟掉，違反本次明示「已觀察 budget 超額不能丟掉」。會讓 sample_resource_budget 經此 scan 成功而回 None，沒有 budget 停損理由。建議在既有接點保留首次 fstat 樣本，並在捨棄各 regular stat/fstat 樣本前查核當下累計 ceiling；勿將多次觀測重複計數，無須新 registry。

信心：高。raw 中的 inode/size/nlink 來自真實系統呼叫，未偽造 stat；只控制並行操作的發生時機。

## Finding 2 — P2：恢復授權丟掉已觀察的多連結狀態

位置：`scripts/tmp_artifact_lifecycle.py:1150`、`:1155`。

`transient_hardlink`：fresh stat nlink=1 → 真實建立同 parent alias hardlink → 首次 fstat **nlink=2** → unlink 原名 → entry.stat ENOENT → pinned nlink=1 → 重讀找到 alias → 候選成功 `(8,1)`。整段沒有 rename，已觀察的多連結未 fail-closed。

此 probe 未證明額外漏算，因此按 P2 列出；但它不符合本候選排除 multiple-links／unlink 的保守授權條件。建議恢復資格也核對首次持有 descriptor 樣本的 nlink，已看到多連結則拒絕此次恢復。信心：高。

## Fresh 證據與重播

- `fresh-suite.raw.log` / `fresh-suite.exit.txt`：46/46 PASS，7.266 秒。原47選集排除唯一 `test_slow_resource_scan_does_not_overlap_or_trigger_catch_up_storm`，該測試會經 run_child 啟動 PGQ，Owner 明禁。保留全部27新測試及19既有測試。精確選集 runner：`run_suite.py`。
- `probe.raw.jsonl` / `probe.exit.txt`：18獨立情境，15符合契約、3反例；exit1 是契約反例結果。具體三例見 finding；其餘覆蓋 stable exact count、rename、unlink、crossparent、初始hardlink、prefix loss、nonflat、open/stat失敗、byte超額、secondrace、replay I/O、deadline、cleanup、nonbrowser。
- 所有18情境的 scanner os.open/os.close 多重集合相符，沒有觀察到 descriptor 遺漏；candidate 的 finally 也覆蓋恢復與拒絕分支。原46選集另覆蓋根／祖先／parent identity、特殊entry allowlist、累計entries、檔數ceiling及重讀拒絕。未證明任意未測 fault 都無 fd leak。
- 重播獨立反例：`sh /private/tmp/observer-independent-20260927-MRrZ71/replay-probe.sh`。指定 Python -B、另建專屬 TMPDIR、結束自清 fixture；预期最後列出三個 contract_failures 並 exit1。只對該 reviewedSHA 有效。
- 本輪 fixture 全部清除。最後僅剩由測試 git 工具產生的 xcrun_db，已隨本輪專屬 fixtures 目錄精確刪除；raw 與 probe 保留。

## 採用限制（不是額外效能修復要求）

主線提供、已讀取 `PPTSKILL-canonical/evidence/edx-core-3-undo-redo/observer-scan-cost-20260927.json`：flat300files median 4.49→31.09ms（6.92x）；mixed320files 4.41→36.54ms（8.29x）；各7輪、counts一致。這是主線正常小fixture證據，不是本 Reviewer fresh benchmark，也不代表真 Chrome／Host04 效能。新增 prestat/open/fstat 可能耗用更多既有5秒觀測窗；不能外推具體主機超時率。

恢復只適用 flat regular-only parent；Default 含子目錄、特殊entry、fresh stat 已ENOENT、open不可讀均不能以此接點恢復。Host04 entry型別與此條件適用性未知。此審查不宣稱 Host04 修復、canonical 可啟用或 whole-card GO。未發現需獨立列報的 P3。

結論：P1 有可重播證據，CODE NO-GO；未修改候選。交回 Mainline 處理明確 finding，不擴新功能。
