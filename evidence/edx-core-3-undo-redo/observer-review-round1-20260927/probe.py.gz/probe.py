import errno, importlib.util, json, os, stat, sys, tempfile
from collections import Counter
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch
REPO = Path('/private/tmp/ai-core-pptskill-observer-20260927')
sys.path.insert(0, str(REPO))
spec = importlib.util.spec_from_file_location('observer_candidate', REPO / 'scripts/tmp_artifact_lifecycle.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
real_open, real_close, real_fstat, real_stat, real_scan = os.open, os.close, os.fstat, os.stat, os.scandir

def probe(kind):
    with tempfile.TemporaryDirectory(prefix='independent-') as tmp:
        sandbox = Path(tmp)
        root = sandbox / 'owned'
        root.mkdir()
        p = root / 'pending'
        p.write_bytes(b'12345678')
        if kind == 'prefix_loss':
            (root / 'a').write_bytes(b'abc')
        if kind == 'initial_hardlink':
            os.link(p, sandbox / 'external')
        if kind == 'nonflat':
            (root / 'z-dir').mkdir()
        events, opened, closed = [], [], []
        scans = 0
        injected = False
        clock = [0.0]
        budget = {'max_bytes': 64, 'max_file_count': 100}
        if kind == 'overbudget':
            budget['max_bytes'] = 4
        def open_tracked(path, flags, *args, **kwargs):
            if path == 'pending' and kind == 'open_failure':
                raise OSError(errno.EIO, 'independent open failure')
            fd = real_open(path, flags, *args, **kwargs)
            opened.append(fd)
            if path == 'pending':
                if kind == 'transient_hardlink':
                    os.link(p, root / 'alias')
                    events.append('real link pending -> alias after fresh stat, before first fstat')
                if kind == 'observed_peak':
                    p.write_bytes(b'x' * 128)
                    events.append('real growth 8 -> 128 before first fstat')
            return fd
        def close_tracked(fd):
            closed.append(fd)
            return real_close(fd)
        def fstat_tracked(fd):
            info = real_fstat(fd)
            if stat.S_ISREG(info.st_mode):
                events.append({'fstat': {'inode': info.st_ino, 'nlink': info.st_nlink, 'size': info.st_size}})
            return info
        def stat_tracked(path, *args, **kwargs):
            if path == 'pending' and kind == 'initial_stat_failure':
                raise FileNotFoundError(errno.ENOENT, 'independent initial stat failure')
            info = real_stat(path, *args, **kwargs)
            if isinstance(path, str) and path in ('pending', 'committed', 'alias'):
                events.append({'fresh_stat': path, 'inode': info.st_ino, 'nlink': info.st_nlink, 'size': info.st_size})
            return info
        class Entry:
            def __init__(self, item):
                self.item, self.name = item, item.name
            def inode(self):
                return self.item.inode()
            def stat(self, *, follow_symlinks=True):
                nonlocal injected
                if self.name == 'pending' and not injected:
                    injected = True
                    if kind in ('unlink', 'initial_hardlink', 'transient_hardlink', 'cleanup', 'nonbrowser'):
                        p.unlink()
                        events.append('real unlink pending')
                    elif kind == 'crossparent':
                        p.rename(sandbox / 'moved')
                    elif kind != 'stable':
                        if kind == 'observed_peak':
                            p.write_bytes(b'12345678')
                            events.append('real shrink 128 -> 8 before ENOENT')
                        p.rename(root / 'committed')
                        if kind == 'prefix_loss':
                            (root / 'a').rename(sandbox / 'lost-prefix')
                if self.name == 'committed' and scans == 2:
                    if kind == 'secondrace':
                        (root / 'committed').rename(root / 'again')
                    if kind == 'replay_peak':
                        (root / 'committed').write_bytes(b'12345678')
                    if kind == 'fallback_special':
                        (root / 'z-link').symlink_to('outside')
                try:
                    info = self.item.stat(follow_symlinks=follow_symlinks)
                    events.append({'entry_stat': self.name, 'size': info.st_size, 'nlink': info.st_nlink})
                    return info
                except OSError as e:
                    events.append({'entry_stat_error': self.name, 'errno': e.errno})
                    raise
        @contextmanager
        def scan(fd):
            nonlocal scans
            scans += 1
            if scans == 2:
                if kind == 'replay_io':
                    raise OSError(errno.EIO, 'independent replay I/O')
                if kind == 'deadline':
                    clock[0] = 5.1
                if kind == 'replay_peak':
                    (root / 'committed').write_bytes(b'x' * 128)
                if kind == 'fallback_special':
                    (root / 'z-link').symlink_to('outside')
            with real_scan(fd) as it:
                yield iter([Entry(e) for e in sorted(it, key=lambda e: e.name)])
        with patch.dict(m.OWNED_ROOTS, {str(root): {'browser_layout': kind != 'nonbrowser'}}), \
             patch.object(m.os, 'open', side_effect=open_tracked), \
             patch.object(m.os, 'close', side_effect=close_tracked), \
             patch.object(m.os, 'stat', side_effect=stat_tracked), \
             patch.object(m.os, 'fstat', side_effect=fstat_tracked), \
             patch.object(m.os, 'scandir', side_effect=scan), \
             patch.object(m.time, 'monotonic', side_effect=lambda: clock[0]):
            try:
                value = m.scan_resource_artifacts(root, None if kind == 'cleanup' else budget)
                outcome = 'ACCEPT'
            except m.LifecycleError as e:
                value = str(e)
                outcome = 'REJECT'
        expected = 'ACCEPT' if kind in ('stable', 'rename') else 'REJECT'
        result = {'case': kind, 'expected': expected, 'actual': outcome, 'value': value,
                  'contract_met': outcome == expected, 'scans': scans,
                  'descriptors_closed': Counter(opened) == Counter(closed), 'events': events}
        print(json.dumps(result, sort_keys=True), flush=True)
        assert result['descriptors_closed'], result
        return result

kinds = ['stable', 'rename', 'unlink', 'crossparent', 'initial_hardlink', 'prefix_loss', 'nonflat',
         'open_failure', 'initial_stat_failure', 'overbudget', 'secondrace', 'replay_io', 'deadline',
         'cleanup', 'nonbrowser', 'transient_hardlink', 'observed_peak', 'replay_peak']
results = [probe(k) for k in kinds]
print(json.dumps({'summary': {'cases': len(results), 'contract_failures': [r['case'] for r in results if not r['contract_met']], 'all_descriptors_closed': all(r['descriptors_closed'] for r in results)}}), flush=True)
sys.exit(1 if any(not r['contract_met'] for r in results) else 0)
